java -jar TheCrookedCarnival.jar
pause